package com.example.spfb;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.spfb.models.Store;
import com.example.spfb.models.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class CreateStoreActivity extends AppCompatActivity implements View.OnClickListener {

    private String currentUserID;

    private EditText edTxtStoreName;
    private Button btnCreateStore;

    private Model model;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_store);

        edTxtStoreName = (EditText) findViewById(R.id.storeName);
        btnCreateStore = (Button) findViewById(R.id.btnCreateStore);
        btnCreateStore.setOnClickListener(this);

        currentUserID = getIntent().getStringExtra("currentUserID");

        model = Model.getInstance();
    }

    private void createStore() {
        String storeName = edTxtStoreName.getText().toString().trim().toLowerCase();
        Store store = new Store(storeName);
        store.owner = currentUserID;


        model.postStore(store, (Boolean created) -> {
            if (!created) {
                Toast.makeText(CreateStoreActivity.this, "Failed to create a store!", Toast.LENGTH_LONG).show();
                return;
            }

            Toast.makeText(CreateStoreActivity.this, "Store Created.", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(this, StoreDashboardActivity.class);
            intent.putExtra("currentUserID", currentUserID);
            startActivity(intent);
        });

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnCreateStore:
                createStore();
                break;
        }
    }
}