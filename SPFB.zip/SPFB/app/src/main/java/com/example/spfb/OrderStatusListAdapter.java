package com.example.spfb;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.spfb.models.Item;
import com.example.spfb.models.Order;

import java.util.List;

public class OrderStatusListAdapter extends ArrayAdapter<Order>  {
    private Context context;
    private int resource;

    public OrderStatusListAdapter(Context context, int resource, List<Order> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
    }

    private class ViewHolder {
        TextView tvStoreName;
        TextView tvCreatedDate;
        TextView tvNumberOfItems;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        Order order = getItem(position);

        String storeName = order.storeName;
        String createdData = order.createdDate;
        String numberOfItems = ((Integer) order.orderItems.size()).toString();

        ViewHolder holder;
        if (convertView == null) {

            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(resource, parent, false);
            holder = new ViewHolder();

            holder.tvStoreName = (TextView) convertView.findViewById(R.id.tvStoreName);
            holder.tvCreatedDate = (TextView) convertView.findViewById(R.id.tvCreatedDate);
            holder.tvNumberOfItems = (TextView) convertView.findViewById(R.id.tvNumberOfItems);

            convertView.setTag(holder);

        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.tvStoreName.setText(storeName);
        holder.tvCreatedDate.setText(createdData);
        holder.tvNumberOfItems.setText(numberOfItems);

        return convertView;
    }
}
