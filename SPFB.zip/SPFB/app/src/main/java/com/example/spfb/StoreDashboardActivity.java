package com.example.spfb;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.spfb.models.Item;
import com.example.spfb.models.Store;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class StoreDashboardActivity extends AppCompatActivity implements View.OnClickListener {

    private String currentUserID;

    private Model model;

    private Store store;

    private ListView lvItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store);

        currentUserID = getIntent().getStringExtra("currentUserID");

        model = Model.getInstance();
        getStore();



        findViewById(R.id.btnListOrders).setOnClickListener(this);
        findViewById(R.id.btnAddItem).setOnClickListener(this);
        lvItems = (ListView) findViewById(R.id.lvItems);
        lvItems.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(StoreDashboardActivity.this, ItemDetailActivity.class);
                intent.putExtra("store", store);
                intent.putExtra("i", i);
                startActivity(intent);
            }
        });
    }


    private void getStore() {
        model.getStoreByOwner(currentUserID, (Store store) -> {
            if (store == null) {
                Intent intent = new Intent(this, CreateStoreActivity.class);
                intent.putExtra("currentUserID", currentUserID);
                startActivity(intent);
                return;
            }
            this.store = store;
            ItemListAdapter adapter = new ItemListAdapter(this, R.layout.item_list_item, store.inventory);
            lvItems.setAdapter(adapter);

        });
    }


    private void addItem() {
        Intent intent = new Intent(this, ItemDetailActivity.class);
        // intent.putExtra("store", store);
        intent.putExtra("store", store);
        startActivity(intent);
    }

    private void listOrders() {
        Intent intent = new Intent(this, StoreOrdersActivity.class);
        // intent.putExtra("store", store);
        intent.putExtra("currentUserID", currentUserID);
        startActivity(intent);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnAddItem:
                addItem();
                break;
            case R.id.btnListOrders:
                listOrders();
                break;
        }
    }
}