package com.example.spfb;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.example.spfb.models.Store;
import com.example.spfb.models.User;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class CustomerDashboardActivity extends AppCompatActivity implements View.OnClickListener  {

    private ListView lvStores;

    private List<String> storeNames;
    private String currentUserID;
    private User currentUser;

    private Button btnOrderStatus;


    private Model model;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_dashboard);

        currentUserID = getIntent().getStringExtra("currentUserID");

        // User user = getIntent().getSerializableExtra("user");

        model = Model.getInstance();

        getCurrentUser();
         getStoreNames();
//        getStoreNamesAvocado();

        lvStores = (ListView) findViewById(R.id.lvStores);

        lvStores.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String storeName = storeNames.get(i);
                Intent intent = new Intent(CustomerDashboardActivity.this, DisplayStoreActivity.class);
                intent.putExtra("storeName", storeName);
                intent.putExtra("currentUser", currentUser);
                startActivity(intent);
            }
        });

        btnOrderStatus = (Button) findViewById(R.id.btnOrderStatus);
        btnOrderStatus.setOnClickListener(this);


    }

    private void getCurrentAvocado() {
        FirebaseDatabase.getInstance().getReference("Users").child(currentUserID)
                .addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull  DataSnapshot snapshot) {
                currentUser = (User) snapshot.getValue(User.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }



    private void getCurrentUser() {
        model.getUser(currentUserID, (User user) -> { this.currentUser = user; });
    }


    private void getStoreNamesAvocado() {
        FirebaseDatabase.getInstance().getReference("Stores")
            .addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    storeNames = new ArrayList<String>();
                    for (DataSnapshot userSnapShot: snapshot.getChildren()) {
                        Store store = userSnapShot.getValue(Store.class);
                        storeNames.add(store.storeName);
                    }

                    ArrayAdapter<String> storeAdapter =
                            new ArrayAdapter<String>(CustomerDashboardActivity.this, android.R.layout.simple_list_item_1, storeNames);
                    lvStores.setAdapter(storeAdapter);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {}
            });
    }



    private void getStoreNames() {
        model.getStoreNames((List<String> storeNames) -> {
            this.storeNames = storeNames;

            ArrayAdapter<String> storeAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, storeNames);
            lvStores.setAdapter(storeAdapter);
        });
    }


    private void orderStatus() {
        Intent intent = new Intent(this, OrderStatusActivity.class);
        intent.putExtra("currentUserID", currentUserID);
        startActivity(intent);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnOrderStatus:
                orderStatus();
                break;
        }
    }
}