package com.example.spfb;

import android.content.Intent;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.example.spfb.models.Order;
import com.example.spfb.models.OrderDescription;
import com.example.spfb.models.Store;
import com.example.spfb.models.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.nio.file.attribute.UserDefinedFileAttributeView;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.SortedMap;
import java.util.function.Consumer;

public class Model {

    private static Model instance;

    private DatabaseReference usersRef;
    private DatabaseReference storesRef;
    private DatabaseReference ordersRef;
    private DatabaseReference ordersDescRef;
    private FirebaseAuth auth;

    private Model() {
        usersRef = FirebaseDatabase.getInstance().getReference("Users");
        storesRef = FirebaseDatabase.getInstance().getReference("Stores");
        ordersRef = FirebaseDatabase.getInstance().getReference("Orders");
        ordersDescRef = FirebaseDatabase.getInstance().getReference("OrdersDescription");
        auth = FirebaseAuth.getInstance();
    }

    public static Model getInstance() {
        if (instance == null)
            instance = new Model();
        return instance;
    }

    public void authenticate(String email, String password, Consumer<User> callback) {
        auth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (!task.isSuccessful()) {
                    callback.accept(null);
                }
                else {
                    usersRef.child(auth.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            User user = snapshot.getValue(User.class);
                            callback.accept(user);
                        }
                        @Override
                        public void onCancelled(@NonNull  DatabaseError error) {

                        }
                    });
                }
            }
        });
    }

    public void getUser(String userID, Consumer<User> callback) {
        usersRef.child(userID).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                User user = snapshot.getValue(User.class);
                callback.accept(user);
            }
            @Override
            public void onCancelled(@NonNull  DatabaseError error) {}
        });
    }

    public void register(String email, String password, Consumer<String> callback) {
        auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                callback.accept(task.isSuccessful() ? auth.getUid() : null);
            }
        });
    }

    public void postUser(User user, Consumer<Boolean> callback) {
        usersRef.child(user.userID).setValue(user).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                callback.accept(task.isSuccessful());
            }
        });
    }

    public void postStore(Store store, Consumer<Boolean> callback) {
        storesRef.child(store.storeName).setValue(store).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                callback.accept(task.isSuccessful());
            }
        });
    }


    public void getStoreByOwner(String owner, Consumer<Store> callback) {
//        Store fakeStore = new Store();
//        fakeStore.storeName = "";
//        fakeStore.owner = "vincent";
//        callback.accept(fakeStore);

        storesRef.orderByChild("owner").equalTo(owner).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot storeSnapShot: snapshot.getChildren()) {
                    Store store = storeSnapShot.getValue(Store.class);
                    callback.accept(store);
                    return;
                }
                // not exist
                callback.accept(null);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    public void getStoreByName(String storeName, Consumer<Store> callback) {
        storesRef.child(storeName).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Store store = snapshot.getValue(Store.class);
                callback.accept(store);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });

    }


    public void getStores(Consumer<List<Store>> callback) {
        storesRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<Store> stores = new ArrayList<Store>();
                for (DataSnapshot userSnapShot: snapshot.getChildren()) {
                    Store store = userSnapShot.getValue(Store.class);
                    stores.add(store);
                }
                callback.accept(stores);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    public void getStoreNames(Consumer<List<String>> callback) {
        storesRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<String> storeNames = new ArrayList<String>();
                for (DataSnapshot userSnapShot: snapshot.getChildren()) {
                    Store store = userSnapShot.getValue(Store.class);
                    storeNames.add(store.storeName);
                }
                callback.accept(storeNames);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }


    public void postOrder(Order order, Consumer<Order> callback) {
        String key = ordersRef.push().getKey();
        order.orderID = key;
        order.createdDate = DateFormat.format(Order.DATETIME_FORMAT, Calendar.getInstance()).toString();
        ordersRef.child(key).setValue(order).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                callback.accept(task.isSuccessful() ? order : null);
            }
        });
    }

    public void postOrderDescription(OrderDescription orderDescription, Consumer<OrderDescription> callback) {
        String key = ordersDescRef.push().getKey();
        ordersDescRef.child(key).setValue(orderDescription).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                callback.accept(task.isSuccessful() ? orderDescription : null);
            }
        });
    }


}
