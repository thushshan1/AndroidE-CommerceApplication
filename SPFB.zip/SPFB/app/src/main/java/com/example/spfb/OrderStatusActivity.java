package com.example.spfb;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.example.spfb.models.Order;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class OrderStatusActivity extends AppCompatActivity {


    private String currentUserID;

    private ListView lvPending, lvCompleted;
    private List<Order> pendingOrders, completedOrders;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_status);
        currentUserID = getIntent().getStringExtra("currentUserID");

        lvPending = (ListView) findViewById(R.id.lvPending);
        lvCompleted = (ListView) findViewById(R.id.lvCompleted);

        getOrders();

    }

    private void getOrders() {
        FirebaseDatabase.getInstance().getReference("Orders")
                .orderByChild("customer").equalTo(currentUserID)
                .addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                pendingOrders = new ArrayList<Order>();
                completedOrders = new ArrayList<Order>();

                for (DataSnapshot orderSnapshot : snapshot.getChildren()) {
                    Order order = (Order) orderSnapshot.getValue(Order.class);
                    if (order.status.equals("pending")) pendingOrders.add(order);
                    else completedOrders.add(order);
                }

                OrderStatusListAdapter pendingAdapter =
                        new OrderStatusListAdapter(OrderStatusActivity.this, R.layout.order_status_list_item, pendingOrders);
                lvPending.setAdapter(pendingAdapter);

                OrderStatusListAdapter completedAdapter =
                        new OrderStatusListAdapter(OrderStatusActivity.this, R.layout.order_status_list_item, completedOrders);
                lvCompleted.setAdapter(completedAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

}