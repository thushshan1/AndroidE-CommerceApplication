package com.example.spfb;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.spfb.models.Item;
import com.example.spfb.models.Order;
import com.example.spfb.models.User;

public class OrderItemActivity extends AppCompatActivity {

    private String storeName;
    private User currentUser;
    private Item item;
    private Order order;

    private TextView tvSelectedItem;
    private EditText edTxtSelectedQuantity;
    private Button btnAdd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_item);

        storeName = getIntent().getStringExtra("storeName");
        currentUser = (User) getIntent().getSerializableExtra("currentUser");
        item = (Item) getIntent().getSerializableExtra("item");
        order = (Order) getIntent().getSerializableExtra("order");

        tvSelectedItem = (TextView) findViewById(R.id.tvSelectedItem);
        tvSelectedItem.setText(item.name);

        edTxtSelectedQuantity = (EditText) findViewById(R.id.edTxtSelectedQuantity);
        edTxtSelectedQuantity.setText("1");

        btnAdd = (Button) findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (edTxtSelectedQuantity.getText().equals("")) return;
                int quantity = Integer.parseInt(edTxtSelectedQuantity.getText().toString());
                Item orderItem = new Item(item.name, item.price, quantity);
                order.orderItems.add(orderItem);
                Intent intent = new Intent(OrderItemActivity.this, DisplayStoreActivity.class);
                intent.putExtra("storeName", storeName);
                intent.putExtra("currentUser", currentUser);
                intent.putExtra("item", item);
                intent.putExtra("order", order);
                startActivity(intent);
            }
        });
    }

}