package com.example.spfb.models;

import java.io.Serializable;

public class User implements Serializable {
    public String email;
    public String name;
    public String age;
    public String userID;

    public String type; // owner, customer


    public User() {

    }

    public User (String userID, String email, String name, String age, boolean isOwner) {
        this.userID = userID;
        this.email = email;
        this.name = name;
        this.age = age;
        this.type = isOwner ? "owner" : "customer";
    }
}
