package com.example.spfb;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.spfb.models.Item;
import com.example.spfb.models.OrderDescription;
import com.example.spfb.models.User;

import java.util.List;

public class ItemListAdapter extends ArrayAdapter<Item> {

    private Context context;
    private int resource;

    public ItemListAdapter(Context context, int resource, List<Item> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
    }

    private class ViewHolder {
        TextView tvItemName;
        TextView tvPrice;
        TextView tvQuantity;
        // Button btnAdd;
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        Item item = getItem(position);

        String itemName = item.name;
        String price = ((Double) item.price).toString();
        String quantity = ((Integer) item.quantity).toString();


        ViewHolder holder;
        if (convertView == null) {

            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(resource, parent, false);
            holder = new ViewHolder();

            holder.tvItemName = (TextView) convertView.findViewById(R.id.tvItemName);
            holder.tvPrice = (TextView) convertView.findViewById(R.id.tvPrice);
            holder.tvQuantity = (TextView) convertView.findViewById(R.id.tvQuantity);

//            holder.btnAdd = (Button) convertView.findViewById(R.id.btnAdd);
//            holder.btnAdd.setTag(item);
//            holder.btnAdd.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    Item item = (Item) view.getTag();
//
//                }
//            });

            convertView.setTag(holder);

        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.tvItemName.setText(itemName);
        holder.tvPrice.setText(price);
        holder.tvQuantity.setText(quantity);

        return convertView;
    }
}
