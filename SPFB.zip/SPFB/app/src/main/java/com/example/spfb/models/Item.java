package com.example.spfb.models;

import java.io.Serializable;

public class Item implements Serializable {
    public String name;
    public double price;
    public int quantity;

    public Item () {}

    public Item(String name, double price, int quantity) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    // order
    public Item(String name, int quantity) {
        this.name = name;
        this.quantity = quantity;
    }

    @Override
    public boolean equals(Object o) {
        Item other = (Item) o;
        return this.name == other.name;

    }


}
