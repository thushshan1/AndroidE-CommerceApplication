package com.example.spfb;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.spfb.models.Item;
import com.example.spfb.models.Store;

public class ItemDetailActivity extends AppCompatActivity implements View.OnClickListener{


    private EditText edTxtItemName, edTxtPrice, edTxtQuantity;
    private Button btnSave;

    private int i;
    private Store store;
    private String currentUserID;

    private Model model;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);

        model = Model.getInstance();

        store = (Store) getIntent().getSerializableExtra("store");
        i = getIntent().getIntExtra("i", -1);

        currentUserID = getIntent().getStringExtra("currentUsrID");

        edTxtItemName = (EditText) findViewById(R.id.edTxtItemName);
        edTxtPrice = (EditText) findViewById(R.id.edTxtPrice);
        edTxtQuantity = (EditText) findViewById(R.id.edTxtQuantity);
        btnSave = (Button) findViewById(R.id.btnSave);
        btnSave.setOnClickListener(this);

        fillEdTxt();

    }

    private void fillEdTxt() {
        //
        if (i != -1) {
            Item item = store.inventory.get(i);
            edTxtItemName.setText(item.name);
            edTxtPrice.setText(((Double) item.price).toString());
            edTxtQuantity.setText(((Integer) item.quantity).toString());
        }

    }

    private void save() {
        Item item = new Item(
                edTxtItemName.getText().toString().trim(),
                Double.parseDouble(edTxtPrice.getText().toString()),
                Integer.parseInt(edTxtQuantity.getText().toString())
        );

        // update
        if (i != -1) {
            store.inventory.set(i, item);
        }
        // add new
        else {
            store.inventory.add(item);
        }

        // update fire base
        model.postStore(store, (Boolean posted) -> {
            if (!posted) {
                Toast.makeText(this, "Failed to save.", Toast.LENGTH_SHORT).show();
                return;
            }
            Toast.makeText(this, "Saved.", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, StoreDashboardActivity.class);
            intent.putExtra("currentUserID", store.owner);
            startActivity(intent);

        });


    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnSave:
                save();
                break;
        }
    }
}