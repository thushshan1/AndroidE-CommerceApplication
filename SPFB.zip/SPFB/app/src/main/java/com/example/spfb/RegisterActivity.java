package com.example.spfb;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.spfb.models.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener{


    private TextView banner;
    private Button btnRegister;
    private EditText edTxtName, edTxtAge, edTxtEmail, edTxtPassword;
    private CheckBox ckOwner;
    private ProgressBar progressBar;

    private Model model;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        banner = (TextView) findViewById(R.id.banner);
        banner.setOnClickListener(this);
        btnRegister = (Button) findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(this);
        edTxtName = (EditText) findViewById(R.id.name);
        edTxtAge = (EditText) findViewById(R.id.age);
        edTxtEmail = (EditText) findViewById(R.id.email);
        edTxtPassword = (EditText) findViewById(R.id.password);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        progressBar.setVisibility(View.GONE);
        ckOwner = (CheckBox) findViewById(R.id.ckOwner);

        model = Model.getInstance();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.banner:
                startActivity(new Intent(this, MainActivity.class));
                break;
            case R.id.btnRegister:
                register();
                break;
        }
    }

    private void register() {
        String email = edTxtEmail.getText().toString().trim();
        String password = edTxtPassword.getText().toString().trim();
        String name = edTxtName.getText().toString().trim();
        String age = edTxtAge.getText().toString().trim();

        // validate
        if (name.isEmpty()) {
            edTxtName.setError("Name is required!");
            edTxtName.requestFocus();
            return;
        }

        if (age.isEmpty()) {
            edTxtAge.setError("Age is required!");
            edTxtAge.requestFocus();
            return;
        }

        if (email.isEmpty()) {
            edTxtEmail.setError("Email is required!");
            edTxtEmail.requestFocus();
            return;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            edTxtEmail.setError("Please provide valid email!");
            edTxtEmail.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            edTxtPassword.setError("password is required!");
            edTxtPassword.requestFocus();
            return;
        }

        if (password.length() < 6) {
            edTxtPassword.setError("Min password length should be 6 characters!");
            edTxtPassword.requestFocus();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);
        model.register(email, password, (String userID) -> {
            if (userID == null) {
                Toast.makeText(RegisterActivity.this, "Failed to register", Toast.LENGTH_LONG).show();
                progressBar.setVisibility(View.GONE);
                return;
            }
            // Toast.makeText(RegisterActivity.this, "registered", Toast.LENGTH_LONG).show();

            User user = new User(userID, email, name, age, ckOwner.isChecked());
            model.postUser(user, (Boolean created) -> {
                if (!created) {
                    Toast.makeText(RegisterActivity.this, "Failed to create a user!", Toast.LENGTH_LONG).show();
                    progressBar.setVisibility(View.GONE);
                    return;
                }

                Toast.makeText(RegisterActivity.this, "user has been registered successfully!", Toast.LENGTH_LONG).show();
                progressBar.setVisibility(View.GONE);

                startActivity(new Intent(RegisterActivity.this, MainActivity.class));
            });
        });

    }
}