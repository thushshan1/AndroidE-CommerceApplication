package com.example.spfb;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.spfb.models.Store;
import com.example.spfb.models.User;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;

public class StoreOrdersActivity extends AppCompatActivity {

    private String currentUserID;

    private Store store;

    private ListView listView;

    private Model model;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_orders);

        currentUserID = getIntent().getStringExtra("currentUserID");
        model = Model.getInstance();

        getStore();


        listView = findViewById(R.id.lvOrders);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String orderID = store.pendingOrders.get(i).orderID;
                Intent intent = new Intent(StoreOrdersActivity.this, OrderDetailActivity.class);
                intent.putExtra("orderID", orderID);
                startActivity(intent);
            }
        });

    }

    private void getStore() {

        Toast.makeText(this, currentUserID, Toast.LENGTH_LONG).show();
        model.getStoreByOwner(currentUserID, (Store store) -> {
            this.store = store;

            // update list View
            OrderDescriptionListAdaptor adapter = new OrderDescriptionListAdaptor(
                    StoreOrdersActivity.this, R.layout.order_description_list_item, store.pendingOrders);
            listView.setAdapter(adapter);
        });
    }


}