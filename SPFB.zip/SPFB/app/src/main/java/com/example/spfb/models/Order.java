package com.example.spfb.models;

import android.text.format.DateFormat;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Order implements Serializable {

    public final static String DATE_FORMAT = "EEEE, dd MMM yyyy";
    public final static String TIME_FORMAT = "hh:mm a";
    public final static String DATETIME_FORMAT = DATE_FORMAT + ", " + TIME_FORMAT;

    public String orderID;
    public String status; // pending, completed
    public String storeName;
    public String customer; // userID

    public String createdDate;

    public List<Item> orderItems;

    public Order () {
        orderItems = new ArrayList<Item>();
    }

    public Order (String storeName, String customer) {
        this();
        this.storeName = storeName;
        this.customer = customer;
        this.status = "pending";
    }

    public void addItem(Item orderItem) {
        orderItems.add(orderItem);
    }

}
