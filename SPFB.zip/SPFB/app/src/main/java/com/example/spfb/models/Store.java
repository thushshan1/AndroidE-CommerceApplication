package com.example.spfb.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Store implements Serializable {
    public String owner; // email
    public String storeName;

    public List<Item> inventory;
    public List<OrderDescription> pendingOrders;
    public List<OrderDescription> completedOrders;

    public Store() {
        inventory = new ArrayList<Item>();
        pendingOrders = new ArrayList<OrderDescription>();
        completedOrders = new ArrayList<OrderDescription>();
    }

    public Store(String storeName) {
        this();
        this.storeName = storeName;
    }

    public String toString() {
        return storeName;
    }



}
