package com.example.spfb;

import android.content.Intent;
import android.view.View;
import android.widget.Toast;

import com.example.spfb.models.User;

public class Presenter {

    private Model model;
    private MainActivity view;

    public Presenter(Model model, MainActivity view) {
        this.model = model;
        this.view = view;
    }

    // API
    public void login(String email, String password) {

//        database_operation.CheckLogIn(username, password, ((User user) -> {
//            // TODO
//        }));


        model.authenticate(email, password, (User user) -> {
            if (user == null) view.failedToLogin();
            else if (user.type.equals("owner")) view.redirectToStoreDashboard(user.userID);
            else view.redirectToCustomerDashboard(user.userID);
        });
    }
}