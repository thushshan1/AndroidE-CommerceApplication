package com.example.spfb;

import com.example.spfb.models.User;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

import java.util.LinkedList;
import java.util.function.Consumer;

import static org.junit.Assert.*;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(MockitoJUnitRunner.class)
public class ExampleUnitTest {

    @Mock
    MainActivity view;

    @Mock
    Model model;

    @Captor
    private ArgumentCaptor<Consumer<User>> captor;


    @Test
    public void testCustomerLoginSus() {
        // Test log in as customer

        String email = "a@mail.com";
        String password = "123456";

        User customer = new User();
        customer.type = "customer";

        Presenter presenter = new Presenter(model, view);

        presenter.login(email, password);

        // verify if model.authenticate() has run
        verify(model).authenticate(eq(email), eq(password), captor.capture());
        Consumer<User> callback = captor.getValue();
        callback.accept(customer);

        // verify if view.redirectToPatientDashboard has run
        verify(view, times(1)).redirectToCustomerDashboard(any());
    }

    @Test
    public void testCustomerLoginFailed() {
        // Test log in as customer

        String email = "a@mail.com";
        String password = "123456";

        User customer = null;

        Presenter presenter = new Presenter(model, view);

        presenter.login(email, password);

        // verify if model.authenticate() has run
        verify(model).authenticate(eq(email), eq(password), captor.capture());
        Consumer<User> callback = captor.getValue();
        callback.accept(customer);

        // verify if view.redirectToPatientDashboard has run
        verify(view, times(0)).redirectToCustomerDashboard(any());

        verify(view, times(1)).failedToLogin();
    }

    @Test
    public void testStoreOwnerSus() {
        // Test log in as customer

        String email = "a@mail.com";
        String password = "123456";

        User owner = new User();
        owner.type = "owner";

        Presenter presenter = new Presenter(model, view);

        presenter.login(email, password);

        // verify if model.authenticate() has run
        verify(model).authenticate(eq(email), eq(password), captor.capture());
        Consumer<User> callback = captor.getValue();
        callback.accept(owner);

        // verify if view.redirectToPatientDashboard has run
        verify(view, times(1)).redirectToStoreDashboard(any());

    }

    @Test
    public void testStoreOwnerFailed() {
        // Test log in as customer

        String email = "a@mail.com";
        String password = "123456";

        User owner = null;

        Presenter presenter = new Presenter(model, view);

        presenter.login(email, password);

        // verify if model.authenticate() has run
        verify(model).authenticate(eq(email), eq(password), captor.capture());
        Consumer<User> callback = captor.getValue();
        callback.accept(owner);

        verify(view, times(0)).redirectToStoreDashboard(any());

        verify(view, times(1)).failedToLogin();

    }


}